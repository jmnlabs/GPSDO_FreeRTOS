# Bufor pierścieniowy Flash — procedura uruchomienia na sprzęcie

[English](FLASH_RING_BRINGUP_EN.md) | **Polski** | [Español](FLASH_RING_BRINGUP_ES.md)

📖 [Strona projektu](../README.md) · [Instrukcja](README_PL.md)

Bufor pierścieniowy z równoważeniem zużycia przechowuje dane „żywe” (nauczony
dryf/tłumienie, kalibracja LC, ostatni PWM) w **sektorze 7** Flasha
(0x08060000, 128 KB) — ostatni sektor, wybrany tak, by firmware zachowało
maksymalną ciągłą przestrzeń poniżej. Rekordy są typowane, więc ustawienia i
dane live dzielą jeden pierścień bez kolizji.
Przełączany **w czasie pracy** komendą `FR 0|1` (zapis przez `ES`, domyślnie
włączony) — bez flagi kompilacji, więc bez zabawy z cache buildu.

Rdzeń logiki jest przetestowany (28 asercji na PC). Za pierwszym razem
uruchamiaj świadomie, z kopią zapasową.

## 0. Najpierw kopia zapasowa (zalecane)

J-Linkiem (lub ST-Linkiem) zrzuć cały Flash, by móc przywrócić w razie potrzeby:

```
JLinkExe -device STM32F411CE -if SWD -speed 4000
> savebin backup_full.bin 0x08000000 0x80000
> exit
```

Przywrócenie później: `loadbin backup_full.bin 0x08000000`.

## 1. Potwierdź, że firmware mieści się poniżej sektora 6

Sprawdź linię rozmiaru: `Sketch uses NNNNNN bytes ...`

`NNNNNN` musi pozostać **poniżej 393216** (0x08060000 − 0x08000000) — tam
zaczyna się sektor 7 i ring. v0.95 mierzyło 216976 B (212 KB), czyli ~176 KB
zapasu; v0.90 miało ~170 KB, więc rośnie.

Nie sugeruj się procentem z IDE. Liczy on od pełnych 512 KB, więc v0.95
pokazuje „41%" — ale sektor 7 jest zajęty przez pierścień, a względem
384 KB, których firmware naprawdę może użyć, prawdziwa liczba to 83%.

Jeśli przyszły build zbliży się do 384 KB, przesuń
pierścień lub odchudź firmware **przed** wgraniem.

## 2. Włącz pierścień, obserwuj `EW`

Pierścień domyślnie **włączony**. Dla pewności, przez port szeregowy:

```
FR 1
ES
```

Następnie `EW`. Na dziewiczym sektorze spodziewaj się:

```
Flash ring: erase cycles=1  slots used=0/255  (sector 7, 0x08060000)
```

`erase cycles=1` jest normalne: pierwszy `begin` nie znajduje ważnego
nagłówka, kasuje raz i zakłada świeży. `slots used=0`, bo nic jeszcze nie
auto-zapisane.

## 3. Wymuś zapis, potwierdź trwałość

Pozwól, by LRN nazbierał dryf ponad próg histerezy (> 8 LSB), albo puść udaną
kalibrację `LC` (zapisuje od razu). Wtedy `EW` powinno pokazać `slots used=1`.
Zresetuj zasilanie. Przy starcie powinieneś zobaczyć:

```
Flash ring: live data recalled
Live store: LRN + LC applied from flash ring
```

Ponownie `EW` — nadal `slots used=1`, a wartości nauczone/kalibracji są
odtworzone. To dowód, że zapis przeżył restart — o to właśnie chodzi.

## 4. Bezpieczeństwo śmieci/kasowania (opcjonalne, dokładne)

Skasuj J-Linkiem tylko sektor 7 i zresetuj:

```
> erase 0x08060000 0x0807FFFF
```

Przy starcie firmware musi wykryć pusty sektor, re-inicjować pierścień
(licznik kasowań rośnie) i wystartować od domyślnych — bez zawieszenia, bez
śmieci. To weryfikuje ścieżkę odporności.

## 5. Wyłączanie

`FR 0` + `ES` zatrzymuje całą aktywność pierścienia: żadnych odczytów, zapisów
ani kasowań. Wartości nauczone/kalibracji żyją wtedy tylko w RAM i giną po
restarcie. Włącz ponownie w dowolnej chwili `FR 1` + `ES`.

## 6. Wgrywanie nowego firmware później (ważne)

- **Bootloader / DFU / Arduino IDE** dotyka tylko sektorów firmware (0–5);
  pierścień w sektorze 7 przetrwa.
- **Pełne kasowanie układu J-Link/ST-Link** czyści wszystko. By zachować
  kalibrację i uczenie, kasuj tylko sektory 0–5:
  ```
  > erase 0x08000000 0x0803FFFF
  > loadbin firmware.bin 0x08000000
  ```
- Jeśli pierścień zostanie wyczyszczony, firmware uczy się/kalibruje od nowa —
  nic się nie psuje, tracisz tylko nagromadzone dostrojenie.

## Wycofanie

Jeśli coś się psuje, `FR 0` + `ES` natychmiast wyłącza pierścień (bez ponownego
wgrywania). Przywróć `backup_full.bin`, jeśli zawartość Flasha została naruszona.
